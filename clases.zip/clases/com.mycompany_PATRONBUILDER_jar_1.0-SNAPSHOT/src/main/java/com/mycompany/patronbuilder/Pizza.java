/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.patronbuilder;


public class Pizza {
    
    private String masa;
    private String salsa;
    private String queso;
    private boolean aceitunas;
    private boolean peperoni;
    
    public Pizza(){}
 
        public void mostrarPizza(){
        boolean x;
        System.out.println("Pizza con: ");
        System.out.println("- Masa: "+ masa);
        System.out.println("- Salsa: "+ salsa);
        System.out.println("- Queso: "+ queso);
        System.out.println("- Aceitunas: "+ (aceitunas ? "si ": "no"));
        System.out.println("- Peperoni: "+ ( peperoni ? "si ": "no"));
        
        }
        
        
        public static class pizzaBuilder{
        
            private Pizza pizza;
            public pizzaBuilder(){
            pizza = new Pizza();
            }
        
          public pizzaBuilder conMasa(String masa){
               
              pizza.masa = masa;
              return this;
          } 
          
          public pizzaBuilder conQueso(String queso){
          
          pizza.queso = queso;
          return this;
          }
           public pizzaBuilder conAceitunas(String aceitunas){
          
          pizza.aceitunas = true;
          return this;
          }
            public pizzaBuilder conPeperoni(String peperoni){
          
          pizza.peperoni = true;
          return this;
          }
          
          
           }
}
    

