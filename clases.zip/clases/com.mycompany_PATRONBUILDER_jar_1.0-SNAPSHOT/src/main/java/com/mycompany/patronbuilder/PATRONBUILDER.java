/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.patronbuilder;

/**
 *
 * @author DIOVARES
 */
public class PATRONBUILDER {

    public static void main(String[] args) {
        Pizza pizzaCompleta = new Pizza();

    }
}
