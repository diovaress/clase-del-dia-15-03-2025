import java.util.LinkedList;
import java.util.Queue;



public class cola {

    public static void main(String[] args) {

        Queue<String> cola = new LinkedList<>();

        cola.offer("primero") ;
        cola.offer("segundo") ;
        cola.offer("tercero") ;
        cola.offer("cuarto") ;
        cola.offer("quinto") ;

        System.out.println("cola actual"+ cola);

        String elementoEliminado= cola.poll();
        System.out.println("println(elementoEliminado" + elementoEliminado);
        System.out.println("la cola despues de eliminar"+ cola);
        System.out.println("la cola desoues de elimnar "+cola  );
        System.out.println("tamaño de cola"+ cola.size()    );
        System.out.println("la cola esta vacia "+cola.isEmpty());
    }



}
